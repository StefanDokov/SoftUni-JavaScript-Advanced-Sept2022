function lockedProfile() {
    
    let maindiv = document.getElementById(`main`);
    let divove = document.getElementsByClassName(`profile`)[0];
    
    listing();
    async function listing(){
     
    let resulto = await fetch(`http://localhost:3030/jsonstore/advanced/profiles`);
    let resdata = await resulto.json();
    for (let i in resdata) {
        let g = divove.cloneNode(true);
        maindiv.appendChild(g);
        
    }
    divove.remove();

    let userinp = document.getElementsByName(`user1Username`);
    let emailinp = document.getElementsByName(`user1Email`);
    let ageinp = document.getElementsByName(`user1Age`);
    let b = 0;
    for (let y in resdata){
      userinp[b].value = resdata[y].username;
      emailinp[b].value = resdata[y].email;
      ageinp[b].value = resdata[y].age;
      b++;
    }
    let s = document.getElementsByClassName(`user1Username`);
    for (let k of s){
        k.style.display = `none`;
    }
    let but = document.getElementsByTagName(`button`);
    for (let el of but) {
        el.addEventListener(`click`, show);
    }


    }

    
    function show(e){
        e.preventDefault();
        
       let lok = e.target.parentElement.querySelectorAll(`input[type=radio]`);
       if (lok[1].checked && e.target.textContent == "Show more") {
        e.target.parentElement.querySelector(`div`).style.display = `block`;
        e.target.textContent = `Hide it`;
        
       } else if (lok[1].checked && e.target.textContent == "Hide it"){
        e.target.parentElement.querySelector(`div`).style.display = `none`;
        e.target.textContent = `Show more`;
       }
       
    }
}