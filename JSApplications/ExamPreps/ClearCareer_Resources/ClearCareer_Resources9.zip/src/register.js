import { html, render } from '../node_modules/lit-html/lit-html.js'

let mainbod = document.querySelector(`main`);

let regRend = () => html`<section id="register">
<div class="form" @submit=${registero}>
  <h2>Register</h2>
  <form class="login-form">
    <input
      type="text"
      name="email"
      id="register-email"
      placeholder="email"
    />
    <input
      type="password"
      name="password"
      id="register-password"
      placeholder="password"
    />
    <input
      type="password"
      name="repassword"
      id="repeat-password"
      placeholder="repeat password"
    />
    <button type="submit">register</button>
    <p class="message">Already registered? <a href="/login">Login</a></p>
  </form>
</div>
</section>`;

export function regRender() {
  render(regRend(), mainbod);
  
}

export async function registero(e) {
e.preventDefault();
  
    let data = new FormData(e.target);

    let { email, password, repassword } = Object.fromEntries(data.entries());
    
try {
  if (!password || !email) {
    return alert("All fields are required!");
  } else if (password != repassword) {
    return alert("Password don't match");
  } else {
    let resp = await fetch(`http://localhost:3030/users/register`, {
      method: `post`,
      headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, password })
  })
  if (resp.status != 200) {
      throw new Error();
  } else {

      let respdata = await resp.json();
      sessionStorage.clear();
      sessionStorage.setItem(`usera`, respdata._id);
      sessionStorage.setItem(`accessToken`, respdata.accessToken);
      window.location = '/';
  }
}
  } catch(err) {
    window.alert(err);
  }
  }
