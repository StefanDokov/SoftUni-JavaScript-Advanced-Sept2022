import { html, render } from '../node_modules/lit-html/lit-html.js'

let mainbod = document.querySelector(`main`);

let regRend = () => html`<section id="register">
<div class="form">
  <h2>Register</h2>
  <form class="login-form">
    <input
      type="text"
      name="email"
      id="register-email"
      placeholder="email"
    />
    <input
      type="password"
      name="password"
      id="register-password"
      placeholder="password"
    />
    <input
      type="password"
      name="repassword"
      id="repeat-password"
      placeholder="repeat password"
    />
    <button type="submit">register</button>
    <p class="message">Already registered? <a href="/login">Login</a></p>
  </form>
</div>
</section>`;

export function regRender() {
  render(regRend(), mainbod);
  registero();
}

export function registero() {

  document.getElementsByClassName(`login-form`)[0].addEventListener(`submit`, registerMe);
  async function registerMe(e) {
    e.preventDefault();
    let data = new FormData(e.target);

    let { email, password, repassword } = Object.fromEntries(data.entries());
    
try {
    if (password != repassword || email == undefined || !password) {
      throw new Error();
    } else {
      let r = await fetch(`http://localhost:3030/users/register`, {
        method: `post`,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      })
      let rdata = await r.json();

      sessionStorage.clear();
      sessionStorage.setItem(`usera`, rdata._id);
      sessionStorage.setItem(`accessToken`, rdata.accessToken);
      window.location ='/dashboard';
    }
  } catch(err) {
    window.alert(err);
  }
  }
}