

let formElement = document.getElementById(`form`);
formElement.addEventListener(`submit`, getter);
let tbod = document.getElementsByTagName(`tbody`)[0];

 async function getter(e) {
     e.preventDefault();
     try{
     let inputite = document.querySelectorAll(`input[type="text"]`);
     
     let formData = new FormData(e.target);
     let {firstName, lastName, facultyNumber, grade} = (Object.fromEntries(formData.entries()));
     
     if (!firstName || !lastName || !facultyNumber || !grade || isNaN(grade) || isNaN(facultyNumber)) {
        return;
     }
     
     tbod.innerHTML = "";
     let resul = await fetch(`http://localhost:3030/jsonstore/collections/students`, {
        method: `post`,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({firstName, lastName, facultyNumber, grade})
     });
     let resuldata = await resul.json();

     let result = await fetch(`http://localhost:3030/jsonstore/collections/students`);
     let resultdata = await result.json();
     let gresult = Object.values(resultdata);
     
     for (let el of gresult) {
        let troww = document.createElement(`tr`);
        let fdow = document.createElement(`td`);
        fdow.textContent = el.firstName;
        let ldow = document.createElement(`td`);
        ldow.textContent = el.lastName;
        let numbow = document.createElement(`td`);
        numbow.textContent = el.facultyNumber;
        let grabow = document.createElement(`td`);
        grabow.textContent = el.grade;
        troww.appendChild(fdow);
        troww.appendChild(ldow);
        troww.appendChild(numbow);
        troww.appendChild(grabow);
        tbod.appendChild(troww);

     }
     
     for (let r of inputite) {
        r.value = "";
     }
    } catch(err){
        throw new Error(`Error`);
    }
    }
   
