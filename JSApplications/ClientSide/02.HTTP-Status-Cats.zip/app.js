import {html, render} from './node_modules/lit-html/lit-html.js';

import {cats} from './catSeeder.js';
window.addEventListener('DOMContentLoaded', gogo);

const catMake = (caterino) => html`<li>
<img src="./images/${caterino.imageLocation}.jpg" width="250" height="250" alt="Card image cap">
<div class="info">
    <button class="showBtn">Show status code</button>
    <div class="status" style="display: none" id="${caterino.id}">
        <h4 class="card-title">Status Code: ${caterino.statusCode}</h4>
        <p class="card-text">${caterino.statusMessage}</p>
    </div>
</div>
</li>`;


let root = document.getElementById(`allCats`);
function gogo() {
let uli = (obj) => html`<ul>
${obj.map(catMake)}
</ul>`

render(uli(cats), root);
let butoni = document.getElementsByClassName(`showBtn`);
for(let el of butoni) {
    el.addEventListener(`click`, showMe);
}

function showMe(e){
   
    if (e.target.textContent == `Show status code`){
        console.log(e.target.textContent)
        e.target.parentElement.children[1].style.display = 'block';
        e.target.textContent = `Hide status code`;
    } else if (e.target.textContent == `Hide status code`){
        e.target.parentElement.children[1].style.display = 'none';
        e.target.textContent = `Show status code`;
    }

}
}
